﻿namespace QuanLyNhaHang
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fAdmin));
            this.tcAdmin = new System.Windows.Forms.TabControl();
            this.tpDoanhThu = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnPrintDT = new System.Windows.Forms.Button();
            this.cbBan = new System.Windows.Forms.ComboBox();
            this.cbTenNguoiDung = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTraCuu = new System.Windows.Forms.Button();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtgvDoanhThu = new System.Windows.Forms.DataGridView();
            this.tpMonAn = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnTuyChon = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtIDMon = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.cbDVT = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.nmGia = new System.Windows.Forms.NumericUpDown();
            this.lblGia = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtTuKhoa = new System.Windows.Forms.TextBox();
            this.lblTuKhoa = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtTenMon = new System.Windows.Forms.TextBox();
            this.lblFoodName = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.cbNhomMon = new System.Windows.Forms.ComboBox();
            this.lblIdFood = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnTim = new System.Windows.Forms.Button();
            this.txtScFoodName = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dtgvMonAn = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.tpBanAn = new System.Windows.Forms.TabPage();
            this.panel20 = new System.Windows.Forms.Panel();
            this.txtTableStatus = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.bntAddKV = new System.Windows.Forms.Button();
            this.panel35 = new System.Windows.Forms.Panel();
            this.cbKhuVuc = new System.Windows.Forms.ComboBox();
            this.lblKhuVuc = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.txtNameTable = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txtIDTableName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.dtgvBanAn = new System.Windows.Forms.DataGridView();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnEditTableFood = new System.Windows.Forms.Button();
            this.btnDeleteTableFood = new System.Windows.Forms.Button();
            this.btnAddTableFood = new System.Windows.Forms.Button();
            this.tpTaiKhoan = new System.Windows.Forms.TabPage();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtIDNguoiDung = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnRePass = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.nmLoaiTK = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txtTenHienThi = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txtTenTk = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.dtgvTaiKhoan = new System.Windows.Forms.DataGridView();
            this.panel26 = new System.Windows.Forms.Panel();
            this.btnSuaTK = new System.Windows.Forms.Button();
            this.btnXoaTK = new System.Windows.Forms.Button();
            this.btnThemTK = new System.Windows.Forms.Button();
            this.tpKho = new System.Windows.Forms.TabPage();
            this.btnTraCuuKho = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpKho2 = new System.Windows.Forms.DateTimePicker();
            this.dtpKho1 = new System.Windows.Forms.DateTimePicker();
            this.dtgvKho = new System.Windows.Forms.DataGridView();
            this.tpPhieuNhap = new System.Windows.Forms.TabPage();
            this.gbCTPhieuNhap = new System.Windows.Forms.GroupBox();
            this.dtgvChiTietPhieuNhap = new System.Windows.Forms.DataGridView();
            this.gbPhieuNhap = new System.Windows.Forms.GroupBox();
            this.btnTaoPhieuNhap = new System.Windows.Forms.Button();
            this.btnTimPN = new System.Windows.Forms.Button();
            this.dtgvPhieuNhap = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.txtNhaCungCap = new System.Windows.Forms.TextBox();
            this.entityCommand1 = new System.Data.Entity.Core.EntityClient.EntityCommand();
            this.tcAdmin.SuspendLayout();
            this.tpDoanhThu.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDoanhThu)).BeginInit();
            this.tpMonAn.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGia)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvMonAn)).BeginInit();
            this.panel3.SuspendLayout();
            this.tpBanAn.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBanAn)).BeginInit();
            this.panel12.SuspendLayout();
            this.tpTaiKhoan.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmLoaiTK)).BeginInit();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).BeginInit();
            this.panel26.SuspendLayout();
            this.tpKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKho)).BeginInit();
            this.tpPhieuNhap.SuspendLayout();
            this.gbCTPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvChiTietPhieuNhap)).BeginInit();
            this.gbPhieuNhap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPhieuNhap)).BeginInit();
            this.SuspendLayout();
            // 
            // tcAdmin
            // 
            this.tcAdmin.Controls.Add(this.tpDoanhThu);
            this.tcAdmin.Controls.Add(this.tpMonAn);
            this.tcAdmin.Controls.Add(this.tpBanAn);
            this.tcAdmin.Controls.Add(this.tpTaiKhoan);
            this.tcAdmin.Controls.Add(this.tpKho);
            this.tcAdmin.Controls.Add(this.tpPhieuNhap);
            this.tcAdmin.Location = new System.Drawing.Point(12, 12);
            this.tcAdmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tcAdmin.Name = "tcAdmin";
            this.tcAdmin.SelectedIndex = 0;
            this.tcAdmin.Size = new System.Drawing.Size(1173, 718);
            this.tcAdmin.TabIndex = 0;
            // 
            // tpDoanhThu
            // 
            this.tpDoanhThu.Controls.Add(this.panel2);
            this.tpDoanhThu.Controls.Add(this.panel1);
            this.tpDoanhThu.Location = new System.Drawing.Point(4, 25);
            this.tpDoanhThu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpDoanhThu.Name = "tpDoanhThu";
            this.tpDoanhThu.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpDoanhThu.Size = new System.Drawing.Size(1165, 689);
            this.tpDoanhThu.TabIndex = 0;
            this.tpDoanhThu.Text = "Doanh thu";
            this.tpDoanhThu.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnPrintDT);
            this.panel2.Controls.Add(this.cbBan);
            this.panel2.Controls.Add(this.cbTenNguoiDung);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnTraCuu);
            this.panel2.Controls.Add(this.dtpEnd);
            this.panel2.Controls.Add(this.dtpStart);
            this.panel2.Location = new System.Drawing.Point(868, 2);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(295, 679);
            this.panel2.TabIndex = 1;
            // 
            // btnPrintDT
            // 
            this.btnPrintDT.BackColor = System.Drawing.Color.White;
            this.btnPrintDT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPrintDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintDT.Location = new System.Drawing.Point(28, 241);
            this.btnPrintDT.Name = "btnPrintDT";
            this.btnPrintDT.Size = new System.Drawing.Size(115, 55);
            this.btnPrintDT.TabIndex = 5;
            this.btnPrintDT.Text = "In";
            this.btnPrintDT.UseVisualStyleBackColor = false;
            this.btnPrintDT.Click += new System.EventHandler(this.btnPrintDT_Click);
            // 
            // cbBan
            // 
            this.cbBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBan.FormattingEnabled = true;
            this.cbBan.Location = new System.Drawing.Point(28, 178);
            this.cbBan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbBan.Name = "cbBan";
            this.cbBan.Size = new System.Drawing.Size(248, 30);
            this.cbBan.TabIndex = 3;
            this.cbBan.Text = "Tên bàn";
            // 
            // cbTenNguoiDung
            // 
            this.cbTenNguoiDung.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTenNguoiDung.FormattingEnabled = true;
            this.cbTenNguoiDung.Location = new System.Drawing.Point(28, 121);
            this.cbTenNguoiDung.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbTenNguoiDung.Name = "cbTenNguoiDung";
            this.cbTenNguoiDung.Size = new System.Drawing.Size(248, 30);
            this.cbTenNguoiDung.TabIndex = 2;
            this.cbTenNguoiDung.Text = "Tên nhân viên";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "Đến";
            // 
            // btnTraCuu
            // 
            this.btnTraCuu.BackColor = System.Drawing.Color.White;
            this.btnTraCuu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTraCuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTraCuu.Location = new System.Drawing.Point(161, 241);
            this.btnTraCuu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTraCuu.Name = "btnTraCuu";
            this.btnTraCuu.Size = new System.Drawing.Size(115, 55);
            this.btnTraCuu.TabIndex = 4;
            this.btnTraCuu.Text = "Tra Cứu";
            this.btnTraCuu.UseVisualStyleBackColor = false;
            this.btnTraCuu.Click += new System.EventHandler(this.btnTraCuu_Click);
            // 
            // dtpEnd
            // 
            this.dtpEnd.Checked = false;
            this.dtpEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEnd.Location = new System.Drawing.Point(28, 59);
            this.dtpEnd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(248, 28);
            this.dtpEnd.TabIndex = 1;
            // 
            // dtpStart
            // 
            this.dtpStart.Checked = false;
            this.dtpStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpStart.Location = new System.Drawing.Point(28, 2);
            this.dtpStart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(248, 28);
            this.dtpStart.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dtgvDoanhThu);
            this.panel1.Location = new System.Drawing.Point(5, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(859, 682);
            this.panel1.TabIndex = 0;
            // 
            // dtgvDoanhThu
            // 
            this.dtgvDoanhThu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvDoanhThu.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDoanhThu.Location = new System.Drawing.Point(3, 2);
            this.dtgvDoanhThu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgvDoanhThu.Name = "dtgvDoanhThu";
            this.dtgvDoanhThu.RowHeadersWidth = 51;
            this.dtgvDoanhThu.RowTemplate.Height = 24;
            this.dtgvDoanhThu.Size = new System.Drawing.Size(853, 676);
            this.dtgvDoanhThu.TabIndex = 0;
            // 
            // tpMonAn
            // 
            this.tpMonAn.Controls.Add(this.panel6);
            this.tpMonAn.Controls.Add(this.panel5);
            this.tpMonAn.Controls.Add(this.panel4);
            this.tpMonAn.Controls.Add(this.panel3);
            this.tpMonAn.Location = new System.Drawing.Point(4, 25);
            this.tpMonAn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpMonAn.Name = "tpMonAn";
            this.tpMonAn.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpMonAn.Size = new System.Drawing.Size(1165, 689);
            this.tpMonAn.TabIndex = 1;
            this.tpMonAn.Text = "Món ăn";
            this.tpMonAn.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnTuyChon);
            this.panel6.Controls.Add(this.panel16);
            this.panel6.Controls.Add(this.panel15);
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(727, 89);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(435, 590);
            this.panel6.TabIndex = 3;
            // 
            // btnTuyChon
            // 
            this.btnTuyChon.BackColor = System.Drawing.Color.White;
            this.btnTuyChon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTuyChon.Location = new System.Drawing.Point(255, 400);
            this.btnTuyChon.Margin = new System.Windows.Forms.Padding(4);
            this.btnTuyChon.Name = "btnTuyChon";
            this.btnTuyChon.Size = new System.Drawing.Size(176, 53);
            this.btnTuyChon.TabIndex = 9;
            this.btnTuyChon.Text = "Tuỳ chọn khác";
            this.btnTuyChon.UseVisualStyleBackColor = false;
            this.btnTuyChon.Click += new System.EventHandler(this.btnTuyChon_Click);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.txtIDMon);
            this.panel16.Controls.Add(this.label9);
            this.panel16.Location = new System.Drawing.Point(3, 2);
            this.panel16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(428, 60);
            this.panel16.TabIndex = 5;
            // 
            // txtIDMon
            // 
            this.txtIDMon.Cursor = System.Windows.Forms.Cursors.No;
            this.txtIDMon.Location = new System.Drawing.Point(163, 22);
            this.txtIDMon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIDMon.Name = "txtIDMon";
            this.txtIDMon.ReadOnly = true;
            this.txtIDMon.Size = new System.Drawing.Size(239, 22);
            this.txtIDMon.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "Mã món ăn";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.cbDVT);
            this.panel15.Controls.Add(this.label8);
            this.panel15.Location = new System.Drawing.Point(3, 267);
            this.panel15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(428, 60);
            this.panel15.TabIndex = 3;
            // 
            // cbDVT
            // 
            this.cbDVT.FormattingEnabled = true;
            this.cbDVT.Location = new System.Drawing.Point(163, 18);
            this.cbDVT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbDVT.Name = "cbDVT";
            this.cbDVT.Size = new System.Drawing.Size(239, 24);
            this.cbDVT.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 24);
            this.label8.TabIndex = 0;
            this.label8.Text = "Đơn vị tính";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.nmGia);
            this.panel10.Controls.Add(this.lblGia);
            this.panel10.Location = new System.Drawing.Point(3, 334);
            this.panel10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(428, 60);
            this.panel10.TabIndex = 4;
            // 
            // nmGia
            // 
            this.nmGia.Location = new System.Drawing.Point(163, 18);
            this.nmGia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nmGia.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nmGia.Name = "nmGia";
            this.nmGia.Size = new System.Drawing.Size(239, 22);
            this.nmGia.TabIndex = 4;
            // 
            // lblGia
            // 
            this.lblGia.AutoSize = true;
            this.lblGia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGia.Location = new System.Drawing.Point(20, 18);
            this.lblGia.Name = "lblGia";
            this.lblGia.Size = new System.Drawing.Size(42, 24);
            this.lblGia.TabIndex = 0;
            this.lblGia.Text = "Giá";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.txtTuKhoa);
            this.panel9.Controls.Add(this.lblTuKhoa);
            this.panel9.Location = new System.Drawing.Point(3, 69);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(428, 60);
            this.panel9.TabIndex = 0;
            // 
            // txtTuKhoa
            // 
            this.txtTuKhoa.Location = new System.Drawing.Point(163, 22);
            this.txtTuKhoa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTuKhoa.Name = "txtTuKhoa";
            this.txtTuKhoa.Size = new System.Drawing.Size(239, 22);
            this.txtTuKhoa.TabIndex = 0;
            // 
            // lblTuKhoa
            // 
            this.lblTuKhoa.AutoSize = true;
            this.lblTuKhoa.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTuKhoa.Location = new System.Drawing.Point(20, 18);
            this.lblTuKhoa.Name = "lblTuKhoa";
            this.lblTuKhoa.Size = new System.Drawing.Size(89, 24);
            this.lblTuKhoa.TabIndex = 0;
            this.lblTuKhoa.Text = "Từ khoá";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtTenMon);
            this.panel8.Controls.Add(this.lblFoodName);
            this.panel8.Location = new System.Drawing.Point(3, 135);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(428, 60);
            this.panel8.TabIndex = 1;
            // 
            // txtTenMon
            // 
            this.txtTenMon.Location = new System.Drawing.Point(163, 21);
            this.txtTenMon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenMon.Name = "txtTenMon";
            this.txtTenMon.Size = new System.Drawing.Size(239, 22);
            this.txtTenMon.TabIndex = 1;
            // 
            // lblFoodName
            // 
            this.lblFoodName.AutoSize = true;
            this.lblFoodName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoodName.Location = new System.Drawing.Point(20, 21);
            this.lblFoodName.Name = "lblFoodName";
            this.lblFoodName.Size = new System.Drawing.Size(93, 24);
            this.lblFoodName.TabIndex = 0;
            this.lblFoodName.Text = "Tên món";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.cbNhomMon);
            this.panel7.Controls.Add(this.lblIdFood);
            this.panel7.Location = new System.Drawing.Point(3, 201);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(428, 60);
            this.panel7.TabIndex = 2;
            // 
            // cbNhomMon
            // 
            this.cbNhomMon.FormattingEnabled = true;
            this.cbNhomMon.Location = new System.Drawing.Point(163, 21);
            this.cbNhomMon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbNhomMon.Name = "cbNhomMon";
            this.cbNhomMon.Size = new System.Drawing.Size(239, 24);
            this.cbNhomMon.TabIndex = 2;
            // 
            // lblIdFood
            // 
            this.lblIdFood.AutoSize = true;
            this.lblIdFood.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdFood.Location = new System.Drawing.Point(20, 21);
            this.lblIdFood.Name = "lblIdFood";
            this.lblIdFood.Size = new System.Drawing.Size(112, 24);
            this.lblIdFood.TabIndex = 0;
            this.lblIdFood.Text = "Nhóm món";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnTim);
            this.panel5.Controls.Add(this.txtScFoodName);
            this.panel5.Location = new System.Drawing.Point(727, 6);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(435, 78);
            this.panel5.TabIndex = 2;
            // 
            // btnTim
            // 
            this.btnTim.BackColor = System.Drawing.Color.White;
            this.btnTim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTim.Location = new System.Drawing.Point(355, 2);
            this.btnTim.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(76, 71);
            this.btnTim.TabIndex = 4;
            this.btnTim.Text = "Tìm";
            this.btnTim.UseVisualStyleBackColor = false;
            this.btnTim.Click += new System.EventHandler(this.btnTim_Click);
            // 
            // txtScFoodName
            // 
            this.txtScFoodName.Location = new System.Drawing.Point(21, 27);
            this.txtScFoodName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtScFoodName.Name = "txtScFoodName";
            this.txtScFoodName.Size = new System.Drawing.Size(311, 22);
            this.txtScFoodName.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dtgvMonAn);
            this.panel4.Location = new System.Drawing.Point(5, 89);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(717, 593);
            this.panel4.TabIndex = 1;
            // 
            // dtgvMonAn
            // 
            this.dtgvMonAn.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvMonAn.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvMonAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvMonAn.Location = new System.Drawing.Point(0, 0);
            this.dtgvMonAn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgvMonAn.Name = "dtgvMonAn";
            this.dtgvMonAn.RowHeadersWidth = 51;
            this.dtgvMonAn.RowTemplate.Height = 24;
            this.dtgvMonAn.Size = new System.Drawing.Size(715, 590);
            this.dtgvMonAn.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnSua);
            this.panel3.Controls.Add(this.btnXoa);
            this.panel3.Controls.Add(this.btnThem);
            this.panel3.Location = new System.Drawing.Point(5, 6);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(717, 78);
            this.panel3.TabIndex = 0;
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.White;
            this.btnSua.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSua.Location = new System.Drawing.Point(167, 2);
            this.btnSua.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(76, 71);
            this.btnSua.TabIndex = 7;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.White;
            this.btnXoa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnXoa.Location = new System.Drawing.Point(85, 2);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(76, 71);
            this.btnXoa.TabIndex = 6;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.White;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnThem.Location = new System.Drawing.Point(3, 2);
            this.btnThem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(76, 71);
            this.btnThem.TabIndex = 5;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // tpBanAn
            // 
            this.tpBanAn.Controls.Add(this.panel20);
            this.tpBanAn.Controls.Add(this.panel17);
            this.tpBanAn.Controls.Add(this.panel14);
            this.tpBanAn.Controls.Add(this.panel12);
            this.tpBanAn.Location = new System.Drawing.Point(4, 25);
            this.tpBanAn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpBanAn.Name = "tpBanAn";
            this.tpBanAn.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpBanAn.Size = new System.Drawing.Size(1165, 689);
            this.tpBanAn.TabIndex = 3;
            this.tpBanAn.Text = "Bàn ăn";
            this.tpBanAn.UseVisualStyleBackColor = true;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.txtTableStatus);
            this.panel20.Controls.Add(this.label4);
            this.panel20.Location = new System.Drawing.Point(725, 290);
            this.panel20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(428, 60);
            this.panel20.TabIndex = 13;
            // 
            // txtTableStatus
            // 
            this.txtTableStatus.Cursor = System.Windows.Forms.Cursors.No;
            this.txtTableStatus.Location = new System.Drawing.Point(173, 18);
            this.txtTableStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTableStatus.Name = "txtTableStatus";
            this.txtTableStatus.ReadOnly = true;
            this.txtTableStatus.Size = new System.Drawing.Size(199, 22);
            this.txtTableStatus.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "Trạng thái";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.bntAddKV);
            this.panel17.Controls.Add(this.panel35);
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Controls.Add(this.panel19);
            this.panel17.Location = new System.Drawing.Point(725, 89);
            this.panel17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(435, 587);
            this.panel17.TabIndex = 7;
            // 
            // bntAddKV
            // 
            this.bntAddKV.BackColor = System.Drawing.Color.White;
            this.bntAddKV.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bntAddKV.Location = new System.Drawing.Point(255, 278);
            this.bntAddKV.Name = "bntAddKV";
            this.bntAddKV.Size = new System.Drawing.Size(144, 46);
            this.bntAddKV.TabIndex = 7;
            this.bntAddKV.Text = "Thêm KV mới";
            this.bntAddKV.UseVisualStyleBackColor = false;
            this.bntAddKV.Click += new System.EventHandler(this.bntAddKV_Click);
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.cbKhuVuc);
            this.panel35.Controls.Add(this.lblKhuVuc);
            this.panel35.Location = new System.Drawing.Point(3, 135);
            this.panel35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(428, 60);
            this.panel35.TabIndex = 12;
            // 
            // cbKhuVuc
            // 
            this.cbKhuVuc.FormattingEnabled = true;
            this.cbKhuVuc.Location = new System.Drawing.Point(171, 22);
            this.cbKhuVuc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbKhuVuc.Name = "cbKhuVuc";
            this.cbKhuVuc.Size = new System.Drawing.Size(199, 24);
            this.cbKhuVuc.TabIndex = 1;
            // 
            // lblKhuVuc
            // 
            this.lblKhuVuc.AutoSize = true;
            this.lblKhuVuc.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKhuVuc.Location = new System.Drawing.Point(20, 18);
            this.lblKhuVuc.Name = "lblKhuVuc";
            this.lblKhuVuc.Size = new System.Drawing.Size(92, 24);
            this.lblKhuVuc.TabIndex = 0;
            this.lblKhuVuc.Text = "Khu Vực";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.txtNameTable);
            this.panel18.Controls.Add(this.label2);
            this.panel18.Location = new System.Drawing.Point(3, 69);
            this.panel18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(428, 60);
            this.panel18.TabIndex = 10;
            // 
            // txtNameTable
            // 
            this.txtNameTable.Location = new System.Drawing.Point(171, 18);
            this.txtNameTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNameTable.Name = "txtNameTable";
            this.txtNameTable.Size = new System.Drawing.Size(199, 22);
            this.txtNameTable.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên bàn";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.txtIDTableName);
            this.panel19.Controls.Add(this.label3);
            this.panel19.Location = new System.Drawing.Point(3, 2);
            this.panel19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(428, 60);
            this.panel19.TabIndex = 9;
            // 
            // txtIDTableName
            // 
            this.txtIDTableName.Cursor = System.Windows.Forms.Cursors.No;
            this.txtIDTableName.Location = new System.Drawing.Point(171, 18);
            this.txtIDTableName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIDTableName.Name = "txtIDTableName";
            this.txtIDTableName.ReadOnly = true;
            this.txtIDTableName.Size = new System.Drawing.Size(199, 22);
            this.txtIDTableName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "ID";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.dtgvBanAn);
            this.panel14.Location = new System.Drawing.Point(5, 89);
            this.panel14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(715, 593);
            this.panel14.TabIndex = 6;
            // 
            // dtgvBanAn
            // 
            this.dtgvBanAn.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvBanAn.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvBanAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvBanAn.Location = new System.Drawing.Point(3, 2);
            this.dtgvBanAn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgvBanAn.Name = "dtgvBanAn";
            this.dtgvBanAn.RowHeadersWidth = 51;
            this.dtgvBanAn.RowTemplate.Height = 24;
            this.dtgvBanAn.Size = new System.Drawing.Size(708, 587);
            this.dtgvBanAn.TabIndex = 0;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.btnEditTableFood);
            this.panel12.Controls.Add(this.btnDeleteTableFood);
            this.panel12.Controls.Add(this.btnAddTableFood);
            this.panel12.Location = new System.Drawing.Point(5, 6);
            this.panel12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(715, 78);
            this.panel12.TabIndex = 5;
            // 
            // btnEditTableFood
            // 
            this.btnEditTableFood.BackColor = System.Drawing.Color.White;
            this.btnEditTableFood.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEditTableFood.Location = new System.Drawing.Point(167, 2);
            this.btnEditTableFood.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEditTableFood.Name = "btnEditTableFood";
            this.btnEditTableFood.Size = new System.Drawing.Size(76, 71);
            this.btnEditTableFood.TabIndex = 5;
            this.btnEditTableFood.Text = "Sửa";
            this.btnEditTableFood.UseVisualStyleBackColor = false;
            this.btnEditTableFood.Click += new System.EventHandler(this.btnEditTableFood_Click);
            // 
            // btnDeleteTableFood
            // 
            this.btnDeleteTableFood.BackColor = System.Drawing.Color.White;
            this.btnDeleteTableFood.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDeleteTableFood.Location = new System.Drawing.Point(85, 2);
            this.btnDeleteTableFood.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDeleteTableFood.Name = "btnDeleteTableFood";
            this.btnDeleteTableFood.Size = new System.Drawing.Size(76, 71);
            this.btnDeleteTableFood.TabIndex = 4;
            this.btnDeleteTableFood.Text = "Xoá";
            this.btnDeleteTableFood.UseVisualStyleBackColor = false;
            this.btnDeleteTableFood.Click += new System.EventHandler(this.btnDeleteTableFood_Click);
            // 
            // btnAddTableFood
            // 
            this.btnAddTableFood.BackColor = System.Drawing.Color.White;
            this.btnAddTableFood.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddTableFood.Location = new System.Drawing.Point(3, 2);
            this.btnAddTableFood.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddTableFood.Name = "btnAddTableFood";
            this.btnAddTableFood.Size = new System.Drawing.Size(76, 71);
            this.btnAddTableFood.TabIndex = 3;
            this.btnAddTableFood.Text = "Thêm";
            this.btnAddTableFood.UseVisualStyleBackColor = false;
            this.btnAddTableFood.Click += new System.EventHandler(this.btnAddTableFood_Click);
            // 
            // tpTaiKhoan
            // 
            this.tpTaiKhoan.Controls.Add(this.panel21);
            this.tpTaiKhoan.Controls.Add(this.panel25);
            this.tpTaiKhoan.Controls.Add(this.panel26);
            this.tpTaiKhoan.Location = new System.Drawing.Point(4, 25);
            this.tpTaiKhoan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpTaiKhoan.Name = "tpTaiKhoan";
            this.tpTaiKhoan.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpTaiKhoan.Size = new System.Drawing.Size(1165, 689);
            this.tpTaiKhoan.TabIndex = 4;
            this.tpTaiKhoan.Text = "Tài Khoản";
            this.tpTaiKhoan.UseVisualStyleBackColor = true;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel13);
            this.panel21.Controls.Add(this.btnRePass);
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Controls.Add(this.panel23);
            this.panel21.Controls.Add(this.panel24);
            this.panel21.Location = new System.Drawing.Point(726, 89);
            this.panel21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(435, 340);
            this.panel21.TabIndex = 10;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.txtIDNguoiDung);
            this.panel13.Controls.Add(this.label11);
            this.panel13.Location = new System.Drawing.Point(3, 2);
            this.panel13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(429, 60);
            this.panel13.TabIndex = 13;
            // 
            // txtIDNguoiDung
            // 
            this.txtIDNguoiDung.Cursor = System.Windows.Forms.Cursors.No;
            this.txtIDNguoiDung.Location = new System.Drawing.Point(211, 18);
            this.txtIDNguoiDung.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIDNguoiDung.Name = "txtIDNguoiDung";
            this.txtIDNguoiDung.ReadOnly = true;
            this.txtIDNguoiDung.Size = new System.Drawing.Size(199, 22);
            this.txtIDNguoiDung.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(20, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "Mã tài khoản:";
            // 
            // btnRePass
            // 
            this.btnRePass.BackColor = System.Drawing.Color.White;
            this.btnRePass.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRePass.Location = new System.Drawing.Point(301, 265);
            this.btnRePass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRePass.Name = "btnRePass";
            this.btnRePass.Size = new System.Drawing.Size(131, 71);
            this.btnRePass.TabIndex = 7;
            this.btnRePass.Text = "Đặt lại mật khẩu";
            this.btnRePass.UseVisualStyleBackColor = false;
            this.btnRePass.Click += new System.EventHandler(this.btnRePass_Click);
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.nmLoaiTK);
            this.panel22.Controls.Add(this.label5);
            this.panel22.Location = new System.Drawing.Point(3, 199);
            this.panel22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(428, 60);
            this.panel22.TabIndex = 11;
            // 
            // nmLoaiTK
            // 
            this.nmLoaiTK.Location = new System.Drawing.Point(211, 18);
            this.nmLoaiTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nmLoaiTK.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmLoaiTK.Name = "nmLoaiTK";
            this.nmLoaiTK.Size = new System.Drawing.Size(120, 22);
            this.nmLoaiTK.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "Loại tài khoản : ";
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.txtTenHienThi);
            this.panel23.Controls.Add(this.lbl);
            this.panel23.Location = new System.Drawing.Point(3, 133);
            this.panel23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(428, 60);
            this.panel23.TabIndex = 10;
            // 
            // txtTenHienThi
            // 
            this.txtTenHienThi.Location = new System.Drawing.Point(211, 18);
            this.txtTenHienThi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenHienThi.Name = "txtTenHienThi";
            this.txtTenHienThi.Size = new System.Drawing.Size(199, 22);
            this.txtTenHienThi.TabIndex = 1;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.Location = new System.Drawing.Point(20, 18);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(182, 24);
            this.lbl.TabIndex = 0;
            this.lbl.Text = "Tên người dùng : ";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.txtTenTk);
            this.panel24.Controls.Add(this.label7);
            this.panel24.Location = new System.Drawing.Point(3, 66);
            this.panel24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(428, 60);
            this.panel24.TabIndex = 9;
            // 
            // txtTenTk
            // 
            this.txtTenTk.Location = new System.Drawing.Point(211, 18);
            this.txtTenTk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenTk.Name = "txtTenTk";
            this.txtTenTk.Size = new System.Drawing.Size(199, 22);
            this.txtTenTk.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(20, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(171, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tên đăng nhập : ";
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.dtgvTaiKhoan);
            this.panel25.Location = new System.Drawing.Point(5, 89);
            this.panel25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(715, 593);
            this.panel25.TabIndex = 9;
            // 
            // dtgvTaiKhoan
            // 
            this.dtgvTaiKhoan.AllowUserToOrderColumns = true;
            this.dtgvTaiKhoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvTaiKhoan.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvTaiKhoan.Location = new System.Drawing.Point(3, 2);
            this.dtgvTaiKhoan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgvTaiKhoan.Name = "dtgvTaiKhoan";
            this.dtgvTaiKhoan.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dtgvTaiKhoan.RowHeadersWidth = 51;
            this.dtgvTaiKhoan.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dtgvTaiKhoan.RowTemplate.Height = 24;
            this.dtgvTaiKhoan.Size = new System.Drawing.Size(708, 587);
            this.dtgvTaiKhoan.TabIndex = 0;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.btnSuaTK);
            this.panel26.Controls.Add(this.btnXoaTK);
            this.panel26.Controls.Add(this.btnThemTK);
            this.panel26.Location = new System.Drawing.Point(5, 6);
            this.panel26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(715, 78);
            this.panel26.TabIndex = 8;
            // 
            // btnSuaTK
            // 
            this.btnSuaTK.BackColor = System.Drawing.Color.White;
            this.btnSuaTK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSuaTK.Location = new System.Drawing.Point(167, 2);
            this.btnSuaTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSuaTK.Name = "btnSuaTK";
            this.btnSuaTK.Size = new System.Drawing.Size(76, 71);
            this.btnSuaTK.TabIndex = 5;
            this.btnSuaTK.Text = "Sửa";
            this.btnSuaTK.UseVisualStyleBackColor = false;
            this.btnSuaTK.Click += new System.EventHandler(this.btnSuaTK_Click);
            // 
            // btnXoaTK
            // 
            this.btnXoaTK.BackColor = System.Drawing.Color.White;
            this.btnXoaTK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnXoaTK.Location = new System.Drawing.Point(85, 2);
            this.btnXoaTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoaTK.Name = "btnXoaTK";
            this.btnXoaTK.Size = new System.Drawing.Size(76, 71);
            this.btnXoaTK.TabIndex = 4;
            this.btnXoaTK.Text = "Xoá";
            this.btnXoaTK.UseVisualStyleBackColor = false;
            this.btnXoaTK.Click += new System.EventHandler(this.btnXoaTK_Click);
            // 
            // btnThemTK
            // 
            this.btnThemTK.BackColor = System.Drawing.Color.White;
            this.btnThemTK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnThemTK.Location = new System.Drawing.Point(3, 2);
            this.btnThemTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThemTK.Name = "btnThemTK";
            this.btnThemTK.Size = new System.Drawing.Size(76, 71);
            this.btnThemTK.TabIndex = 3;
            this.btnThemTK.Text = "Thêm";
            this.btnThemTK.UseVisualStyleBackColor = false;
            this.btnThemTK.Click += new System.EventHandler(this.btnThemTK_Click);
            // 
            // tpKho
            // 
            this.tpKho.Controls.Add(this.btnTraCuuKho);
            this.tpKho.Controls.Add(this.label6);
            this.tpKho.Controls.Add(this.dtpKho2);
            this.tpKho.Controls.Add(this.dtpKho1);
            this.tpKho.Controls.Add(this.dtgvKho);
            this.tpKho.Location = new System.Drawing.Point(4, 25);
            this.tpKho.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpKho.Name = "tpKho";
            this.tpKho.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpKho.Size = new System.Drawing.Size(1165, 689);
            this.tpKho.TabIndex = 5;
            this.tpKho.Text = "Kho";
            this.tpKho.UseVisualStyleBackColor = true;
            // 
            // btnTraCuuKho
            // 
            this.btnTraCuuKho.BackColor = System.Drawing.Color.White;
            this.btnTraCuuKho.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTraCuuKho.Location = new System.Drawing.Point(527, 9);
            this.btnTraCuuKho.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTraCuuKho.Name = "btnTraCuuKho";
            this.btnTraCuuKho.Size = new System.Drawing.Size(113, 34);
            this.btnTraCuuKho.TabIndex = 2;
            this.btnTraCuuKho.Text = "Tra cứu";
            this.btnTraCuuKho.UseVisualStyleBackColor = false;
            this.btnTraCuuKho.Click += new System.EventHandler(this.btnTraCuuKho_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(221, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "Đến";
            // 
            // dtpKho2
            // 
            this.dtpKho2.Location = new System.Drawing.Point(271, 15);
            this.dtpKho2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpKho2.Name = "dtpKho2";
            this.dtpKho2.Size = new System.Drawing.Size(200, 22);
            this.dtpKho2.TabIndex = 1;
            // 
            // dtpKho1
            // 
            this.dtpKho1.Location = new System.Drawing.Point(5, 15);
            this.dtpKho1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpKho1.Name = "dtpKho1";
            this.dtpKho1.Size = new System.Drawing.Size(200, 22);
            this.dtpKho1.TabIndex = 0;
            // 
            // dtgvKho
            // 
            this.dtgvKho.AllowUserToOrderColumns = true;
            this.dtgvKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvKho.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvKho.Location = new System.Drawing.Point(3, 53);
            this.dtgvKho.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgvKho.Name = "dtgvKho";
            this.dtgvKho.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dtgvKho.RowHeadersWidth = 51;
            this.dtgvKho.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dtgvKho.RowTemplate.Height = 24;
            this.dtgvKho.Size = new System.Drawing.Size(1157, 629);
            this.dtgvKho.TabIndex = 0;
            // 
            // tpPhieuNhap
            // 
            this.tpPhieuNhap.Controls.Add(this.gbCTPhieuNhap);
            this.tpPhieuNhap.Controls.Add(this.gbPhieuNhap);
            this.tpPhieuNhap.Location = new System.Drawing.Point(4, 25);
            this.tpPhieuNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpPhieuNhap.Name = "tpPhieuNhap";
            this.tpPhieuNhap.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpPhieuNhap.Size = new System.Drawing.Size(1165, 689);
            this.tpPhieuNhap.TabIndex = 6;
            this.tpPhieuNhap.Text = "Phiếu nhập";
            this.tpPhieuNhap.UseVisualStyleBackColor = true;
            // 
            // gbCTPhieuNhap
            // 
            this.gbCTPhieuNhap.Controls.Add(this.dtgvChiTietPhieuNhap);
            this.gbCTPhieuNhap.Location = new System.Drawing.Point(613, 4);
            this.gbCTPhieuNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCTPhieuNhap.Name = "gbCTPhieuNhap";
            this.gbCTPhieuNhap.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCTPhieuNhap.Size = new System.Drawing.Size(547, 678);
            this.gbCTPhieuNhap.TabIndex = 8;
            this.gbCTPhieuNhap.TabStop = false;
            this.gbCTPhieuNhap.Text = "Chi tiết";
            // 
            // dtgvChiTietPhieuNhap
            // 
            this.dtgvChiTietPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvChiTietPhieuNhap.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvChiTietPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvChiTietPhieuNhap.Location = new System.Drawing.Point(5, 27);
            this.dtgvChiTietPhieuNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgvChiTietPhieuNhap.Name = "dtgvChiTietPhieuNhap";
            this.dtgvChiTietPhieuNhap.RowHeadersWidth = 51;
            this.dtgvChiTietPhieuNhap.RowTemplate.Height = 24;
            this.dtgvChiTietPhieuNhap.Size = new System.Drawing.Size(535, 647);
            this.dtgvChiTietPhieuNhap.TabIndex = 0;
            // 
            // gbPhieuNhap
            // 
            this.gbPhieuNhap.Controls.Add(this.btnTaoPhieuNhap);
            this.gbPhieuNhap.Controls.Add(this.btnTimPN);
            this.gbPhieuNhap.Controls.Add(this.dtgvPhieuNhap);
            this.gbPhieuNhap.Controls.Add(this.label10);
            this.gbPhieuNhap.Controls.Add(this.txtNhaCungCap);
            this.gbPhieuNhap.Location = new System.Drawing.Point(9, 4);
            this.gbPhieuNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbPhieuNhap.Name = "gbPhieuNhap";
            this.gbPhieuNhap.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbPhieuNhap.Size = new System.Drawing.Size(597, 678);
            this.gbPhieuNhap.TabIndex = 7;
            this.gbPhieuNhap.TabStop = false;
            this.gbPhieuNhap.Text = "Phiếu nhập";
            // 
            // btnTaoPhieuNhap
            // 
            this.btnTaoPhieuNhap.BackColor = System.Drawing.Color.White;
            this.btnTaoPhieuNhap.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTaoPhieuNhap.Location = new System.Drawing.Point(414, 19);
            this.btnTaoPhieuNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTaoPhieuNhap.Name = "btnTaoPhieuNhap";
            this.btnTaoPhieuNhap.Size = new System.Drawing.Size(160, 32);
            this.btnTaoPhieuNhap.TabIndex = 2;
            this.btnTaoPhieuNhap.Text = "Tạo phiếu nhập";
            this.btnTaoPhieuNhap.UseVisualStyleBackColor = false;
            this.btnTaoPhieuNhap.Click += new System.EventHandler(this.btnTaoPhieuNhap_Click);
            // 
            // btnTimPN
            // 
            this.btnTimPN.BackColor = System.Drawing.Color.White;
            this.btnTimPN.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTimPN.Location = new System.Drawing.Point(315, 21);
            this.btnTimPN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTimPN.Name = "btnTimPN";
            this.btnTimPN.Size = new System.Drawing.Size(77, 30);
            this.btnTimPN.TabIndex = 1;
            this.btnTimPN.Text = "Tìm";
            this.btnTimPN.UseVisualStyleBackColor = false;
            this.btnTimPN.Click += new System.EventHandler(this.btnTimPN_Click);
            // 
            // dtgvPhieuNhap
            // 
            this.dtgvPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvPhieuNhap.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvPhieuNhap.Location = new System.Drawing.Point(0, 69);
            this.dtgvPhieuNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgvPhieuNhap.Name = "dtgvPhieuNhap";
            this.dtgvPhieuNhap.RowHeadersWidth = 51;
            this.dtgvPhieuNhap.RowTemplate.Height = 24;
            this.dtgvPhieuNhap.Size = new System.Drawing.Size(595, 605);
            this.dtgvPhieuNhap.TabIndex = 2;
            this.dtgvPhieuNhap.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvPhieuNhap_CellClick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "Nhà cung cấp ";
            // 
            // txtNhaCungCap
            // 
            this.txtNhaCungCap.Location = new System.Drawing.Point(127, 23);
            this.txtNhaCungCap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhaCungCap.Name = "txtNhaCungCap";
            this.txtNhaCungCap.Size = new System.Drawing.Size(167, 22);
            this.txtNhaCungCap.TabIndex = 0;
            this.txtNhaCungCap.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMaPhieuNhap_KeyDown);
            // 
            // entityCommand1
            // 
            this.entityCommand1.CommandTimeout = 0;
            this.entityCommand1.CommandTree = null;
            this.entityCommand1.Connection = null;
            this.entityCommand1.EnablePlanCaching = true;
            this.entityCommand1.Transaction = null;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1193, 747);
            this.Controls.Add(this.tcAdmin);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.tcAdmin.ResumeLayout(false);
            this.tpDoanhThu.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDoanhThu)).EndInit();
            this.tpMonAn.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGia)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvMonAn)).EndInit();
            this.panel3.ResumeLayout(false);
            this.tpBanAn.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBanAn)).EndInit();
            this.panel12.ResumeLayout(false);
            this.tpTaiKhoan.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmLoaiTK)).EndInit();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).EndInit();
            this.panel26.ResumeLayout(false);
            this.tpKho.ResumeLayout(false);
            this.tpKho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKho)).EndInit();
            this.tpPhieuNhap.ResumeLayout(false);
            this.gbCTPhieuNhap.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvChiTietPhieuNhap)).EndInit();
            this.gbPhieuNhap.ResumeLayout(false);
            this.gbPhieuNhap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPhieuNhap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcAdmin;
        private System.Windows.Forms.TabPage tpDoanhThu;
        private System.Windows.Forms.TabPage tpMonAn;
        private System.Windows.Forms.TabPage tpBanAn;
        private System.Windows.Forms.TabPage tpTaiKhoan;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTraCuu;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnTim;
        private System.Windows.Forms.TextBox txtScFoodName;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lblGia;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lblTuKhoa;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lblFoodName;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblIdFood;
        private System.Windows.Forms.NumericUpDown nmGia;
        private System.Windows.Forms.ComboBox cbNhomMon;
        private System.Windows.Forms.DataGridView dtgvDoanhThu;
        private System.Windows.Forms.DataGridView dtgvMonAn;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox txtNameTable;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txtIDTableName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.DataGridView dtgvBanAn;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btnEditTableFood;
        private System.Windows.Forms.Button btnDeleteTableFood;
        private System.Windows.Forms.Button btnAddTableFood;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox txtTenHienThi;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txtTenTk;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.DataGridView dtgvTaiKhoan;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Button btnSuaTK;
        private System.Windows.Forms.Button btnXoaTK;
        private System.Windows.Forms.Button btnThemTK;
        private System.Windows.Forms.Button btnRePass;
        private System.Windows.Forms.TabPage tpKho;
        private System.Data.Entity.Core.EntityClient.EntityCommand entityCommand1;
        private System.Windows.Forms.DataGridView dtgvKho;
        private System.Windows.Forms.TextBox txtTuKhoa;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.ComboBox cbDVT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTenMon;
        private System.Windows.Forms.NumericUpDown nmLoaiTK;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtIDMon;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbTenNguoiDung;
        private System.Windows.Forms.ComboBox cbBan;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label lblKhuVuc;
        private System.Windows.Forms.ComboBox cbKhuVuc;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox txtTableStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnTraCuuKho;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpKho2;
        private System.Windows.Forms.DateTimePicker dtpKho1;
        private System.Windows.Forms.TabPage tpPhieuNhap;
        private System.Windows.Forms.GroupBox gbPhieuNhap;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNhaCungCap;
        private System.Windows.Forms.GroupBox gbCTPhieuNhap;
        private System.Windows.Forms.DataGridView dtgvChiTietPhieuNhap;
        private System.Windows.Forms.Button btnTimPN;
        private System.Windows.Forms.DataGridView dtgvPhieuNhap;
        private System.Windows.Forms.Button btnTaoPhieuNhap;
        private System.Windows.Forms.Button btnTuyChon;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtIDNguoiDung;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bntAddKV;
        private System.Windows.Forms.Button btnPrintDT;
    }
}