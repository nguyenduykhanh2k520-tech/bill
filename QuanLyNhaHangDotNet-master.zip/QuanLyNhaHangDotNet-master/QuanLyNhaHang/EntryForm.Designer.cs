﻿namespace QuanLyNhaHang
{
    partial class FormPhieuNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPhieuNhap));
            this.gbPhieuNhap = new System.Windows.Forms.GroupBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtShipper = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTaoPN = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbNhaCungCap = new System.Windows.Forms.ComboBox();
            this.lblNhaCungCap = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtMaPhieuNhap = new System.Windows.Forms.TextBox();
            this.lblUserName = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtpkNgayNhap = new System.Windows.Forms.DateTimePicker();
            this.lblNgayNhap = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtNguoiGiao = new System.Windows.Forms.TextBox();
            this.lblNguoiGiao = new System.Windows.Forms.Label();
            this.gbChiTietPhieuNhap = new System.Windows.Forms.GroupBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.dtpHsd = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.btnXacNhan = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.nmSoLuong = new System.Windows.Forms.NumericUpDown();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.cbLoaiMatHang = new System.Windows.Forms.ComboBox();
            this.lblTenLoaiMatHang = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtTenMatHang = new System.Windows.Forms.TextBox();
            this.lblTenMatHang = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.nmGiaNhap = new System.Windows.Forms.NumericUpDown();
            this.lblGiaNhap = new System.Windows.Forms.Label();
            this.dtgvHienThiPhieuNhap = new System.Windows.Forms.DataGridView();
            this.gbPhieuNhap.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.gbChiTietPhieuNhap.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSoLuong)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGiaNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHienThiPhieuNhap)).BeginInit();
            this.SuspendLayout();
            // 
            // gbPhieuNhap
            // 
            this.gbPhieuNhap.Controls.Add(this.btnUpdate);
            this.gbPhieuNhap.Controls.Add(this.panel9);
            this.gbPhieuNhap.Controls.Add(this.btnTaoPN);
            this.gbPhieuNhap.Controls.Add(this.panel4);
            this.gbPhieuNhap.Controls.Add(this.panel2);
            this.gbPhieuNhap.Location = new System.Drawing.Point(12, 12);
            this.gbPhieuNhap.Name = "gbPhieuNhap";
            this.gbPhieuNhap.Size = new System.Drawing.Size(554, 327);
            this.gbPhieuNhap.TabIndex = 0;
            this.gbPhieuNhap.TabStop = false;
            this.gbPhieuNhap.Text = "Phiếu nhập";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdate.Location = new System.Drawing.Point(6, 217);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(144, 54);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "Thêm thông tin cho phiếu nhập";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.txtShipper);
            this.panel9.Controls.Add(this.label1);
            this.panel9.Location = new System.Drawing.Point(3, 168);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(539, 43);
            this.panel9.TabIndex = 3;
            // 
            // txtShipper
            // 
            this.txtShipper.Location = new System.Drawing.Point(215, 10);
            this.txtShipper.Name = "txtShipper";
            this.txtShipper.Size = new System.Drawing.Size(310, 22);
            this.txtShipper.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Người giao";
            // 
            // btnTaoPN
            // 
            this.btnTaoPN.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTaoPN.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTaoPN.Location = new System.Drawing.Point(416, 217);
            this.btnTaoPN.Name = "btnTaoPN";
            this.btnTaoPN.Size = new System.Drawing.Size(123, 54);
            this.btnTaoPN.TabIndex = 4;
            this.btnTaoPN.Text = "Tạo phiếu";
            this.btnTaoPN.UseVisualStyleBackColor = false;
            this.btnTaoPN.Click += new System.EventHandler(this.btnTaoPN_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cbNhaCungCap);
            this.panel4.Controls.Add(this.lblNhaCungCap);
            this.panel4.Location = new System.Drawing.Point(3, 119);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(539, 43);
            this.panel4.TabIndex = 2;
            // 
            // cbNhaCungCap
            // 
            this.cbNhaCungCap.FormattingEnabled = true;
            this.cbNhaCungCap.Location = new System.Drawing.Point(212, 10);
            this.cbNhaCungCap.Name = "cbNhaCungCap";
            this.cbNhaCungCap.Size = new System.Drawing.Size(310, 24);
            this.cbNhaCungCap.TabIndex = 1;
            // 
            // lblNhaCungCap
            // 
            this.lblNhaCungCap.AutoSize = true;
            this.lblNhaCungCap.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNhaCungCap.Location = new System.Drawing.Point(20, 10);
            this.lblNhaCungCap.Name = "lblNhaCungCap";
            this.lblNhaCungCap.Size = new System.Drawing.Size(153, 24);
            this.lblNhaCungCap.TabIndex = 0;
            this.lblNhaCungCap.Text = "Nhà cung cấp :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtMaPhieuNhap);
            this.panel2.Controls.Add(this.lblUserName);
            this.panel2.Location = new System.Drawing.Point(0, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(539, 43);
            this.panel2.TabIndex = 0;
            // 
            // txtMaPhieuNhap
            // 
            this.txtMaPhieuNhap.Location = new System.Drawing.Point(215, 11);
            this.txtMaPhieuNhap.Name = "txtMaPhieuNhap";
            this.txtMaPhieuNhap.ReadOnly = true;
            this.txtMaPhieuNhap.Size = new System.Drawing.Size(310, 22);
            this.txtMaPhieuNhap.TabIndex = 0;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(20, 11);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(162, 24);
            this.lblUserName.TabIndex = 0;
            this.lblUserName.Text = "Mã phiếu nhập :";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dtpkNgayNhap);
            this.panel1.Controls.Add(this.lblNgayNhap);
            this.panel1.Location = new System.Drawing.Point(12, 82);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 43);
            this.panel1.TabIndex = 1;
            // 
            // dtpkNgayNhap
            // 
            this.dtpkNgayNhap.Location = new System.Drawing.Point(215, 10);
            this.dtpkNgayNhap.Name = "dtpkNgayNhap";
            this.dtpkNgayNhap.Size = new System.Drawing.Size(310, 22);
            this.dtpkNgayNhap.TabIndex = 0;
            // 
            // lblNgayNhap
            // 
            this.lblNgayNhap.AutoSize = true;
            this.lblNgayNhap.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgayNhap.Location = new System.Drawing.Point(20, 8);
            this.lblNgayNhap.Name = "lblNgayNhap";
            this.lblNgayNhap.Size = new System.Drawing.Size(130, 24);
            this.lblNgayNhap.TabIndex = 0;
            this.lblNgayNhap.Text = "Ngày nhập : ";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtNguoiGiao);
            this.panel3.Controls.Add(this.lblNguoiGiao);
            this.panel3.Location = new System.Drawing.Point(12, 155);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(539, 55);
            this.panel3.TabIndex = 2;
            // 
            // txtNguoiGiao
            // 
            this.txtNguoiGiao.Location = new System.Drawing.Point(215, 19);
            this.txtNguoiGiao.Name = "txtNguoiGiao";
            this.txtNguoiGiao.Size = new System.Drawing.Size(310, 22);
            this.txtNguoiGiao.TabIndex = 2;
            // 
            // lblNguoiGiao
            // 
            this.lblNguoiGiao.AutoSize = true;
            this.lblNguoiGiao.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNguoiGiao.Location = new System.Drawing.Point(20, 19);
            this.lblNguoiGiao.Name = "lblNguoiGiao";
            this.lblNguoiGiao.Size = new System.Drawing.Size(128, 24);
            this.lblNguoiGiao.TabIndex = 0;
            this.lblNguoiGiao.Text = "Người giao :";
            // 
            // gbChiTietPhieuNhap
            // 
            this.gbChiTietPhieuNhap.Controls.Add(this.panel10);
            this.gbChiTietPhieuNhap.Controls.Add(this.btnXacNhan);
            this.gbChiTietPhieuNhap.Controls.Add(this.btnHuy);
            this.gbChiTietPhieuNhap.Controls.Add(this.panel6);
            this.gbChiTietPhieuNhap.Controls.Add(this.panel7);
            this.gbChiTietPhieuNhap.Controls.Add(this.panel8);
            this.gbChiTietPhieuNhap.Controls.Add(this.panel5);
            this.gbChiTietPhieuNhap.Location = new System.Drawing.Point(572, 12);
            this.gbChiTietPhieuNhap.Name = "gbChiTietPhieuNhap";
            this.gbChiTietPhieuNhap.Size = new System.Drawing.Size(555, 327);
            this.gbChiTietPhieuNhap.TabIndex = 0;
            this.gbChiTietPhieuNhap.TabStop = false;
            this.gbChiTietPhieuNhap.Text = "Chi tiết phiếu nhập";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.dtpHsd);
            this.panel10.Controls.Add(this.label2);
            this.panel10.Location = new System.Drawing.Point(6, 216);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(539, 43);
            this.panel10.TabIndex = 8;
            // 
            // dtpHsd
            // 
            this.dtpHsd.Location = new System.Drawing.Point(215, 10);
            this.dtpHsd.Name = "dtpHsd";
            this.dtpHsd.Size = new System.Drawing.Size(201, 22);
            this.dtpHsd.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Hạn sử dụng : ";
            // 
            // btnXacNhan
            // 
            this.btnXacNhan.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXacNhan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnXacNhan.Location = new System.Drawing.Point(406, 265);
            this.btnXacNhan.Name = "btnXacNhan";
            this.btnXacNhan.Size = new System.Drawing.Size(123, 54);
            this.btnXacNhan.TabIndex = 9;
            this.btnXacNhan.Text = "Thêm";
            this.btnXacNhan.UseVisualStyleBackColor = false;
            this.btnXacNhan.Click += new System.EventHandler(this.btnXacNhan_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnHuy.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHuy.Location = new System.Drawing.Point(277, 265);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(123, 54);
            this.btnHuy.TabIndex = 10;
            this.btnHuy.Text = "Huỷ";
            this.btnHuy.UseVisualStyleBackColor = false;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.nmSoLuong);
            this.panel6.Controls.Add(this.lblSoLuong);
            this.panel6.Location = new System.Drawing.Point(6, 119);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(539, 43);
            this.panel6.TabIndex = 6;
            // 
            // nmSoLuong
            // 
            this.nmSoLuong.Location = new System.Drawing.Point(218, 10);
            this.nmSoLuong.Name = "nmSoLuong";
            this.nmSoLuong.Size = new System.Drawing.Size(65, 22);
            this.nmSoLuong.TabIndex = 6;
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoLuong.Location = new System.Drawing.Point(20, 10);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(111, 24);
            this.lblSoLuong.TabIndex = 0;
            this.lblSoLuong.Text = "Số lượng :";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.cbLoaiMatHang);
            this.panel7.Controls.Add(this.lblTenLoaiMatHang);
            this.panel7.Location = new System.Drawing.Point(6, 70);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(539, 43);
            this.panel7.TabIndex = 5;
            // 
            // cbLoaiMatHang
            // 
            this.cbLoaiMatHang.FormattingEnabled = true;
            this.cbLoaiMatHang.Location = new System.Drawing.Point(218, 10);
            this.cbLoaiMatHang.Name = "cbLoaiMatHang";
            this.cbLoaiMatHang.Size = new System.Drawing.Size(307, 24);
            this.cbLoaiMatHang.TabIndex = 5;
            // 
            // lblTenLoaiMatHang
            // 
            this.lblTenLoaiMatHang.AutoSize = true;
            this.lblTenLoaiMatHang.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenLoaiMatHang.Location = new System.Drawing.Point(20, 10);
            this.lblTenLoaiMatHang.Name = "lblTenLoaiMatHang";
            this.lblTenLoaiMatHang.Size = new System.Drawing.Size(192, 24);
            this.lblTenLoaiMatHang.TabIndex = 0;
            this.lblTenLoaiMatHang.Text = "Tên loại mặt hàng :";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtTenMatHang);
            this.panel8.Controls.Add(this.lblTenMatHang);
            this.panel8.Location = new System.Drawing.Point(6, 21);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(539, 43);
            this.panel8.TabIndex = 5;
            // 
            // txtTenMatHang
            // 
            this.txtTenMatHang.Location = new System.Drawing.Point(215, 11);
            this.txtTenMatHang.Name = "txtTenMatHang";
            this.txtTenMatHang.Size = new System.Drawing.Size(310, 22);
            this.txtTenMatHang.TabIndex = 5;
            // 
            // lblTenMatHang
            // 
            this.lblTenMatHang.AutoSize = true;
            this.lblTenMatHang.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenMatHang.Location = new System.Drawing.Point(20, 11);
            this.lblTenMatHang.Name = "lblTenMatHang";
            this.lblTenMatHang.Size = new System.Drawing.Size(153, 24);
            this.lblTenMatHang.TabIndex = 0;
            this.lblTenMatHang.Text = "Tên mặt hàng :";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.nmGiaNhap);
            this.panel5.Controls.Add(this.lblGiaNhap);
            this.panel5.Location = new System.Drawing.Point(6, 168);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(539, 43);
            this.panel5.TabIndex = 7;
            // 
            // nmGiaNhap
            // 
            this.nmGiaNhap.Location = new System.Drawing.Point(216, 10);
            this.nmGiaNhap.Name = "nmGiaNhap";
            this.nmGiaNhap.Size = new System.Drawing.Size(307, 22);
            this.nmGiaNhap.TabIndex = 7;
            // 
            // lblGiaNhap
            // 
            this.lblGiaNhap.AutoSize = true;
            this.lblGiaNhap.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGiaNhap.Location = new System.Drawing.Point(20, 10);
            this.lblGiaNhap.Name = "lblGiaNhap";
            this.lblGiaNhap.Size = new System.Drawing.Size(114, 24);
            this.lblGiaNhap.TabIndex = 0;
            this.lblGiaNhap.Text = "Giá nhập : ";
            // 
            // dtgvHienThiPhieuNhap
            // 
            this.dtgvHienThiPhieuNhap.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvHienThiPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvHienThiPhieuNhap.Location = new System.Drawing.Point(15, 345);
            this.dtgvHienThiPhieuNhap.Name = "dtgvHienThiPhieuNhap";
            this.dtgvHienThiPhieuNhap.RowHeadersWidth = 51;
            this.dtgvHienThiPhieuNhap.RowTemplate.Height = 24;
            this.dtgvHienThiPhieuNhap.Size = new System.Drawing.Size(1112, 406);
            this.dtgvHienThiPhieuNhap.TabIndex = 3;
            // 
            // FormPhieuNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1134, 759);
            this.Controls.Add(this.dtgvHienThiPhieuNhap);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbChiTietPhieuNhap);
            this.Controls.Add(this.gbPhieuNhap);
            this.Controls.Add(this.panel3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormPhieuNhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phiếu nhập";
            this.Load += new System.EventHandler(this.FormPhieuNhap_Load);
            this.gbPhieuNhap.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.gbChiTietPhieuNhap.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSoLuong)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGiaNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHienThiPhieuNhap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbPhieuNhap;
        private System.Windows.Forms.GroupBox gbChiTietPhieuNhap;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblNhaCungCap;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtNguoiGiao;
        private System.Windows.Forms.Label lblNguoiGiao;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtMaPhieuNhap;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblNgayNhap;
        private System.Windows.Forms.DateTimePicker dtpkNgayNhap;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblTenLoaiMatHang;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtTenMatHang;
        private System.Windows.Forms.Label lblTenMatHang;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblGiaNhap;
        private System.Windows.Forms.ComboBox cbLoaiMatHang;
        private System.Windows.Forms.NumericUpDown nmSoLuong;
        private System.Windows.Forms.Button btnXacNhan;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.NumericUpDown nmGiaNhap;
        private System.Windows.Forms.Button btnTaoPN;
        private System.Windows.Forms.ComboBox cbNhaCungCap;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txtShipper;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dtgvHienThiPhieuNhap;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.DateTimePicker dtpHsd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUpdate;
    }
}