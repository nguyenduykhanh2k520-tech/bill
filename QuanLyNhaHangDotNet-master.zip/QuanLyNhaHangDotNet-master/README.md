Dự án sử dụng Windows Form và SQL Server Express
